﻿using ProtoLibrary;
using System.Windows;

namespace WpfClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Greeter.GreeterClient _client;

        public MainWindow(Greeter.GreeterClient client)
        {
            _client = client;
            InitializeComponent();
        }

        private async void OnSayHelloAsyncClick(object sender, RoutedEventArgs e)
        {
            var response = await _client.SayHelloAsync(new HelloRequest { Name = "Async Name" });
            responseText.Text = response.Message;
        }

        private void OnSayHelloClick(object sender, RoutedEventArgs e)
        {
            var response = _client.SayHello(new HelloRequest { Name = "Sync Name" });
            responseText.Text = response.Message;
        }
    }
}
